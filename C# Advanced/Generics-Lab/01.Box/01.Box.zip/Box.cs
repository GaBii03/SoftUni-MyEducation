﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfT
{
	public class Box<T>
	{
		public List<T> items;

		public Box()
		{
			List<T> items = new List<T>();
		}

		public int Counter
		{
			get
			{
				return items.Count;
			}
		}
		
		public void Add(T element)
		{
			items.Add(element);
		}

		public T Remove()
		{
			var element = items[items.Count - 1];
			items.RemoveAt(items.Count - 1);
			return element;
		}

	}
}
