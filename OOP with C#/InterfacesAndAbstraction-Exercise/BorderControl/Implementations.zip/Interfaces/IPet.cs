﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Interfaces
{
	interface IPet
	{
		public string Name { get; set; }
		public string Birthday { get; set; }
	}
}
