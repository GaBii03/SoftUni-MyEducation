﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Interfaces
{
	interface IRebel
	{
		public string Name { get; set; }

		public int Age { get; set; }

		public string Group { get; set; }
	}
}
