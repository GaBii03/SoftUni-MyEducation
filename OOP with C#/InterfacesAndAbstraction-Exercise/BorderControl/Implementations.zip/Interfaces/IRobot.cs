﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Interfaces
{
	interface IRobot
	{
		public string Model { get; set; }
		public string Id { get; set; }
	}
}
