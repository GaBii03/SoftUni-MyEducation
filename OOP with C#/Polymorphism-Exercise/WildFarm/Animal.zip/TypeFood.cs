﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
	public enum TypeFood
	{
		Vegetable,
		Fruit,
		Meat,
		Seeds
	}
}
